
express=require('express');
DataSet=require('../Model/model')
Singnup=require('../Model/signup');
app=express();


app.get('/data',async(req,res)=>{
    batch=await DataSet.find({})
    try{
        res.send(batch);
    }
    catch
    {
        res.send("Error"); 
    }
})

app.get('/getSign',async(req,res)=>{
    signup=await Singnup.find({});
    try
    {
        res.send(signup);
    }
    catch(err)
    {
        res.send(err);
    }
})

app.post('/post',async(req,res)=>{
    batch=new DataSet(req.body);
    try
    {
        await batch.save();
        res.send(batch);
    }
    catch(err)
    {
        res.status(500).send(err);
    }
})
app.post('/signup',async(req,res)=>{
    signup=new Singnup(req.body);
    try
    {
        await signup.save();
        res.send(signup);
    }
    catch(err)
    {
        res.status(500).send(err);
    }
})

app.patch('/PUT/:id',async(req,res)=>{
    try
    {
        await DataSet.findByIdAndUpdate(req.params.id,req.body);
        await DataSet.save();
    }
    catch
    {
        res.send("enter valid id");
    }
})

app.delete('/Delete/:id',async(req,res)=>{
    try
    {
        batch=await DataSet.findByIdAndDelete(req.params.id,req.body);
        if(!batch)
        {
            res.status(600).send('no batch');
        }
       
    }
    catch(err)
    {
        res.status(404).send('enter valid id');
    }
})

 module.exports= app;
