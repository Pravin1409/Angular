
mongoose=require('mongoose');
Signup=new mongoose.Schema({
    name:{type:String},
    mobile:{type:Number},
    email:{type:String},
    pass:{type:String}
});
Signup=mongoose.model("signup",Signup);
module.exports=Signup;