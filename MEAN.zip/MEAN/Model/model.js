
mongoose = require("mongoose");

DataSet=new mongoose.Schema({
  
    name: {
      type: String,
    },
    email: {
      type:String,
     },
    mobile:{
      type:Number,
    },
    address:{type:String,},
    services:{type:String,},
  });
data=mongoose.model("data",DataSet);
module.exports=data;

