import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private _http:HttpClient) { }
  // data post
POST(data:any)
{
  return this._http.post<any>('api/post',data).pipe(map((res:any)=>{
    return res;
  }));
}

// get data

getRestorent()
{
  return this._http.get<any>('api/data').pipe(map((res:any)=>{
    return res;
  }));
}
//  update method
updateRestorent(data:any,id:number){
  return this._http.put("api/PUT",+id,data).pipe(map((res)=>{
    return res;
  }))
}


// Delete Method
DeleteRestorent(id:any)
{
  return this._http.delete<any>("api/Delete/"+id)
}


SignUp(data:any)
{
  return this._http.post('api/sign',data).pipe(map((res)=>{
    return res;
  }))
}
 
getSignUp()
{
  return this._http.get<any>('api/getSign').pipe(map((res)=>{
    return res;
  }))
}



}