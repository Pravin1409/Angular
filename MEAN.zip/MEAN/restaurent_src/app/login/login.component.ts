import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _fobj:FormBuilder,private _http:HttpClient,private router:Router) { }
  login!:FormGroup;
  ngOnInit(): void 
  {
  this.login=this._fobj.group({
    email:['',Validators.required],
    pass:['',Validators.required]
  })

  }
  Login()
  {
    this._http.get<any>('api/getSign').subscribe(res=>{
      const user =res.find((a:any)=>{
        return a.email === this.login.value.email && a.pass===this.login.value.pass

      })
      if(user)
      {
        alert("login user success");
        this.login.reset();
        this.router.navigate(['/dash']);
      }
      else
      {
        alert("error enter valid email and passward ");
        // this.router.navigate(['/login']);
        this.login.reset();
        
      
      }
    })
  }

}
