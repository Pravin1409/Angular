import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private _fobj: FormBuilder, private _http: HttpClient, private router: Router) { }
  signup!: FormGroup;
  ngOnInit(): void {
    this.signup = this._fobj.group({
      name: ['', Validators.required],
      mobile: ['', Validators.required],
      email: ['', Validators.required],
      pass: ['', Validators.required],
    })
  }
  SignUp() 
  {
    this._http.post<any>('api/signup', this.signup.value).subscribe((res) => {
      alert("Signup succeful");
      this.signup.reset();
      this.router.navigate(['/login']);
    }, err => {
      alert("Error Response");
    })
  }



}
