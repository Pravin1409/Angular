import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { from } from 'rxjs';
import { DataService } from '../data.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  Record:any;

  constructor(private _fobj:FormBuilder,private _sobj:DataService) { }
  form!:FormGroup;

  ngOnInit(): void {
    this.form=this._fobj.group({
      name:['',[Validators.required]],
      email:['',[Validators.required]],
      mobile:['',[Validators.required]],
      address:['',[Validators.required]],
      services:['',[Validators.required]],
    })

   this.getAllData();
  }

  Fun()
  {
    this._sobj.POST(this.form.value).subscribe((res)=>{
      console.log("ok");
      this.form.reset();

      alert("Successfuly added record")
      this.getAllData();
    })
  }

  // get all
  getAllData()
  {
    this._sobj.getRestorent().subscribe(res=>{
      this.Record=res;
    })
  }


//  Deletedata
  deleteResto(data:any)
  {
    this._sobj.DeleteRestorent(data._id).subscribe(res=>{
   
    })
    alert("delete succeful completed")
    this.getAllData();
  }
}
