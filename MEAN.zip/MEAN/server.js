
express=require('express');
mongoose = require('mongoose');
bodyParser=require('body-parser');
Routes=require('./Routes/routes.js')

eobj = express();
eobj.use(bodyParser.json());
eobj.use(Routes);

eobj.listen(5001, (request,responce) => {
  console.log("Server is running at 5001");
});

eobj.get('/', (request, responce) =>{
  responce.send("Marvellous server is running");
});


Database='mongodb+srv://pravin:pravin@cluster0.zw0aubl.mongodb.net/?retryWrites=true&w=majority';
mongoose.connect(Database).then(()=>{
    console.log("Succes connection..");
}).catch((err)=>{
    console.log("Fail")
})
